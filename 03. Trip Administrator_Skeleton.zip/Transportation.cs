﻿using System;
namespace TripAdministrations
{
    [Flags]
    public enum Transportation
    {
        BUS,
        PLANE,
        NONE
    }
}
